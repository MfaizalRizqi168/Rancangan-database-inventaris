--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.ruang DROP CONSTRAINT ruang_pkey;
ALTER TABLE ONLY public.petugas DROP CONSTRAINT petugas_pkey;
ALTER TABLE ONLY public.peminjaman DROP CONSTRAINT peminjaman_pkey;
ALTER TABLE ONLY public.pegawai DROP CONSTRAINT pegawai_pkey;
ALTER TABLE ONLY public.jenis DROP CONSTRAINT jenis_pkey;
ALTER TABLE ONLY public.inventaris DROP CONSTRAINT inventaris_pkey;
ALTER TABLE ONLY public.detail_pinjaman DROP CONSTRAINT detail_pinjaman_pkey;
ALTER TABLE public.tb_level ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.ruang ALTER COLUMN id_ruang DROP DEFAULT;
ALTER TABLE public.petugas ALTER COLUMN id_petugas DROP DEFAULT;
ALTER TABLE public.peminjaman ALTER COLUMN id_pegawai DROP DEFAULT;
ALTER TABLE public.peminjaman ALTER COLUMN id_peminjaman DROP DEFAULT;
ALTER TABLE public.pegawai ALTER COLUMN id_pegawai DROP DEFAULT;
ALTER TABLE public.jenis ALTER COLUMN id_jenis DROP DEFAULT;
ALTER TABLE public.inventaris ALTER COLUMN id_inventaris DROP DEFAULT;
ALTER TABLE public.detail_pinjaman ALTER COLUMN id_detail_pinjam DROP DEFAULT;
DROP SEQUENCE public.tb_level_id_level_seq;
DROP TABLE public.tb_level;
DROP SEQUENCE public.ruang_id_ruang_seq;
DROP TABLE public.ruang;
DROP SEQUENCE public.petugas_id_petugas_seq;
DROP TABLE public.petugas;
DROP SEQUENCE public.peminjaman_id_peminjaman_seq;
DROP SEQUENCE public.peminjaman_id_pegawai_seq;
DROP TABLE public.peminjaman;
DROP SEQUENCE public.pegawai_id_pegawai_seq;
DROP TABLE public.pegawai;
DROP SEQUENCE public.jenis_id_jenis_seq;
DROP TABLE public.jenis;
DROP SEQUENCE public.inventaris_id_inventaris_seq;
DROP TABLE public.inventaris;
DROP SEQUENCE public.detail_pinjaman_id_detail_pinjam_seq;
DROP TABLE public.detail_pinjaman;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_pinjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_pinjaman (
    id_detail_pinjam integer NOT NULL,
    id_inventaris integer,
    jumlah integer
);


ALTER TABLE detail_pinjaman OWNER TO postgres;

--
-- Name: detail_pinjaman_id_detail_pinjam_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE detail_pinjaman_id_detail_pinjam_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE detail_pinjaman_id_detail_pinjam_seq OWNER TO postgres;

--
-- Name: detail_pinjaman_id_detail_pinjam_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE detail_pinjaman_id_detail_pinjam_seq OWNED BY detail_pinjaman.id_detail_pinjam;


--
-- Name: inventaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inventaris (
    id_inventaris integer NOT NULL,
    nama character varying(50),
    kondisi character varying(50),
    keterangan character varying(50),
    jumlah integer,
    id_jenis character varying(50),
    tanggal_register date,
    id_ruang integer,
    kode_inventaris integer,
    id_petugas integer
);


ALTER TABLE inventaris OWNER TO postgres;

--
-- Name: inventaris_id_inventaris_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE inventaris_id_inventaris_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE inventaris_id_inventaris_seq OWNER TO postgres;

--
-- Name: inventaris_id_inventaris_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE inventaris_id_inventaris_seq OWNED BY inventaris.id_inventaris;


--
-- Name: jenis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE jenis (
    id_jenis integer NOT NULL,
    nama_jenis character varying(50),
    kode_jenis character varying(50),
    keterangan character varying(50)
);


ALTER TABLE jenis OWNER TO postgres;

--
-- Name: jenis_id_jenis_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE jenis_id_jenis_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE jenis_id_jenis_seq OWNER TO postgres;

--
-- Name: jenis_id_jenis_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE jenis_id_jenis_seq OWNED BY jenis.id_jenis;


--
-- Name: pegawai; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pegawai (
    id_pegawai integer NOT NULL,
    nama_pegawai text,
    nip integer,
    alamat character varying(50)
);


ALTER TABLE pegawai OWNER TO postgres;

--
-- Name: pegawai_id_pegawai_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pegawai_id_pegawai_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pegawai_id_pegawai_seq OWNER TO postgres;

--
-- Name: pegawai_id_pegawai_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pegawai_id_pegawai_seq OWNED BY pegawai.id_pegawai;


--
-- Name: peminjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE peminjaman (
    id_peminjaman integer NOT NULL,
    tanggal_pinjam date,
    tanggal_kembali date,
    status_peminjaman character varying(50),
    id_pegawai integer NOT NULL
);


ALTER TABLE peminjaman OWNER TO postgres;

--
-- Name: peminjaman_id_pegawai_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE peminjaman_id_pegawai_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE peminjaman_id_pegawai_seq OWNER TO postgres;

--
-- Name: peminjaman_id_pegawai_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE peminjaman_id_pegawai_seq OWNED BY peminjaman.id_pegawai;


--
-- Name: peminjaman_id_peminjaman_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE peminjaman_id_peminjaman_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE peminjaman_id_peminjaman_seq OWNER TO postgres;

--
-- Name: peminjaman_id_peminjaman_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE peminjaman_id_peminjaman_seq OWNED BY peminjaman.id_peminjaman;


--
-- Name: petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE petugas (
    id_petugas integer NOT NULL,
    username character varying(50),
    password character varying(50),
    nama_petugas character varying(50),
    id_level integer
);


ALTER TABLE petugas OWNER TO postgres;

--
-- Name: petugas_id_petugas_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE petugas_id_petugas_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE petugas_id_petugas_seq OWNER TO postgres;

--
-- Name: petugas_id_petugas_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE petugas_id_petugas_seq OWNED BY petugas.id_petugas;


--
-- Name: ruang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE ruang (
    id_ruang integer NOT NULL,
    nama_ruang text,
    kode_ruang integer,
    keterangan character varying(50)
);


ALTER TABLE ruang OWNER TO postgres;

--
-- Name: ruang_id_ruang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ruang_id_ruang_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ruang_id_ruang_seq OWNER TO postgres;

--
-- Name: ruang_id_ruang_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ruang_id_ruang_seq OWNED BY ruang.id_ruang;


--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama_level character varying(50)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_level_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_level_id_level_seq OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_level_id_level_seq OWNED BY tb_level.id_level;


--
-- Name: detail_pinjaman id_detail_pinjam; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_pinjaman ALTER COLUMN id_detail_pinjam SET DEFAULT nextval('detail_pinjaman_id_detail_pinjam_seq'::regclass);


--
-- Name: inventaris id_inventaris; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventaris ALTER COLUMN id_inventaris SET DEFAULT nextval('inventaris_id_inventaris_seq'::regclass);


--
-- Name: jenis id_jenis; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY jenis ALTER COLUMN id_jenis SET DEFAULT nextval('jenis_id_jenis_seq'::regclass);


--
-- Name: pegawai id_pegawai; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pegawai ALTER COLUMN id_pegawai SET DEFAULT nextval('pegawai_id_pegawai_seq'::regclass);


--
-- Name: peminjaman id_peminjaman; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY peminjaman ALTER COLUMN id_peminjaman SET DEFAULT nextval('peminjaman_id_peminjaman_seq'::regclass);


--
-- Name: peminjaman id_pegawai; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY peminjaman ALTER COLUMN id_pegawai SET DEFAULT nextval('peminjaman_id_pegawai_seq'::regclass);


--
-- Name: petugas id_petugas; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY petugas ALTER COLUMN id_petugas SET DEFAULT nextval('petugas_id_petugas_seq'::regclass);


--
-- Name: ruang id_ruang; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ruang ALTER COLUMN id_ruang SET DEFAULT nextval('ruang_id_ruang_seq'::regclass);


--
-- Name: tb_level id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level ALTER COLUMN id_level SET DEFAULT nextval('tb_level_id_level_seq'::regclass);


--
-- Data for Name: detail_pinjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_pinjaman (id_detail_pinjam, id_inventaris, jumlah) FROM stdin;
\.
COPY detail_pinjaman (id_detail_pinjam, id_inventaris, jumlah) FROM '$$PATH$$/2871.dat';

--
-- Data for Name: inventaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM stdin;
\.
COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM '$$PATH$$/2867.dat';

--
-- Data for Name: jenis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM stdin;
\.
COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM '$$PATH$$/2863.dat';

--
-- Data for Name: pegawai; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM stdin;
\.
COPY pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM '$$PATH$$/2878.dat';

--
-- Data for Name: peminjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM stdin;
\.
COPY peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM '$$PATH$$/2876.dat';

--
-- Data for Name: petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2869.dat';

--
-- Data for Name: ruang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM stdin;
\.
COPY ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2873.dat';

--
-- Name: detail_pinjaman_id_detail_pinjam_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('detail_pinjaman_id_detail_pinjam_seq', 1, false);


--
-- Name: inventaris_id_inventaris_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('inventaris_id_inventaris_seq', 1, false);


--
-- Name: jenis_id_jenis_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('jenis_id_jenis_seq', 1, false);


--
-- Name: pegawai_id_pegawai_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pegawai_id_pegawai_seq', 1, false);


--
-- Name: peminjaman_id_pegawai_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('peminjaman_id_pegawai_seq', 1, false);


--
-- Name: peminjaman_id_peminjaman_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('peminjaman_id_peminjaman_seq', 1, false);


--
-- Name: petugas_id_petugas_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('petugas_id_petugas_seq', 1, false);


--
-- Name: ruang_id_ruang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ruang_id_ruang_seq', 1, false);


--
-- Name: tb_level_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_level_id_level_seq', 1, false);


--
-- Name: detail_pinjaman detail_pinjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_pinjaman
    ADD CONSTRAINT detail_pinjaman_pkey PRIMARY KEY (id_detail_pinjam);


--
-- Name: inventaris inventaris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventaris
    ADD CONSTRAINT inventaris_pkey PRIMARY KEY (id_inventaris);


--
-- Name: jenis jenis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY jenis
    ADD CONSTRAINT jenis_pkey PRIMARY KEY (id_jenis);


--
-- Name: pegawai pegawai_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pegawai
    ADD CONSTRAINT pegawai_pkey PRIMARY KEY (id_pegawai);


--
-- Name: peminjaman peminjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY peminjaman
    ADD CONSTRAINT peminjaman_pkey PRIMARY KEY (id_peminjaman);


--
-- Name: petugas petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY petugas
    ADD CONSTRAINT petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: ruang ruang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ruang
    ADD CONSTRAINT ruang_pkey PRIMARY KEY (id_ruang);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- PostgreSQL database dump complete
--

